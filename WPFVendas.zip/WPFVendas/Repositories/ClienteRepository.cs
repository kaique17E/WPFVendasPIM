﻿using WpfVendas.Repositories;
using WPFVendas.Models;

namespace WpfVendas.Repositories
{
    public class ClienteRepository : Repository<Cliente>
    {
        public Cliente GetById(int id)
        {
            return items.FirstOrDefault(c => c.Id == id);
        }
    }
}