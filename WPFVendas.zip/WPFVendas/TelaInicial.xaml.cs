﻿using System;
using System.Windows;
using WPFVendas.Views;  // Certifique-se de que o namespace das Views está correto

namespace WPFVendas
{
    public partial class TelaInicial : Window
    {
        public TelaInicial()
        {
            InitializeComponent();
        }

        // Clique no botão "Clientes" para navegar para a página de clientes
        private void btnClientes_Click(object sender, RoutedEventArgs e)

        {
            MainFrame.Navigate(new PageClientes());  // Substitua PageClientes com a sua página correspondente
        }

        // Clique no botão "Fornecedores" para navegar para a página de fornecedores
        private void btnFornecedores_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new PageFornecedores());  // Substitua PageFornecedores com a sua página correspondente
        }

        // Clique no botão "Recursos" para abrir a janela de recursos
        private void btnRecursos_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new PageRecursos());

        }

        // Clique no botão "Sair" para fechar a aplicação
        private void btnSair_Click(object sender, RoutedEventArgs e)
        {
            this.Close();  // Fecha a janela principal e encerra o aplicativo
        }
    }
}
