﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfVendas.ViewModels;
using WPFVendas.Models;

namespace WPFVendas.Views
{
    /// <summary>
    /// Interação lógica para PageRecursos.xam
    /// </summary>
    public partial class PageRecursos : Page
    {

        private RecursoViewModel _viewModel;

        public object RecursoDataGrid { get; private set; }

        public PageRecursos()
        {
            InitializeComponent();
            _viewModel = new RecursoViewModel();
            DataContext = _viewModel;
        }
        private async void btnAtualizar_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.Recursos.Clear();
            await _viewModel.CarregarRecursosDaAPI();
        }
        private void btnAddRecurso_Click(object sender, RoutedEventArgs e)
        {
            var janelaCadastro = new cadRecursos
            {
                Owner = Window.GetWindow(this)
            };

            var viewModel = new RecursoCadastroViewModel(janelaCadastro.Close, null);
            janelaCadastro.DataContext = viewModel;
            janelaCadastro.ShowDialog();
        }
    
        }



    }

