﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfVendas.ViewModels;
using WpfVendas.Views;

namespace WPFVendas.Views
{
    /// <summary>
    /// Interação lógica para PageFornecedores.xam
    /// </summary>
    public partial class PageFornecedores : Page
    {
        private FornecedorViewModel _viewModel;
        public PageFornecedores()
        {
            InitializeComponent();
            _viewModel = new FornecedorViewModel();
            DataContext = _viewModel;
        }

        private void btnEditar_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void btnExcluir_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnAddFornecedor_Click(object sender, RoutedEventArgs e)
        {
            var janelaCadastro = new cadFornecedor
            {
                Owner = Window.GetWindow(this)
            };
            var viewModel = new 
                FornecedorCadastroViewModel(janelaCadastro.Close, null);
            janelaCadastro.DataContext = viewModel;
            janelaCadastro.ShowDialog();
        }

        private void btnAtualizar_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.Fornecedores.Clear();
            _viewModel.CarregarFornecedoresDaAPI();

        }
       
    }
}
