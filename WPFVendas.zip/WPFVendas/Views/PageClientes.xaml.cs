﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

using WpfVendas.ViewModels;
using WPFVendas.Views;
using WPFVendas.Models;
using System; // Importar modelos necessários (se ainda não estiver)

namespace WPFVendas.Views
{
    /// <summary>
    /// Interação lógica para PageClientes.xaml
    /// </summary>
    public partial class PageClientes : Page
    {
        private ClienteViewModel _viewModel;
   
        public PageClientes()
        {
            InitializeComponent();
            _viewModel = new ClienteViewModel();
            DataContext = _viewModel;
        }

        // Função para atualizar a lista de clientes
        private async void btnAtualizar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _viewModel.Clientes.Clear();  // Limpar a lista de clientes antes de atualizar
                await _viewModel.CarregarClientesDaAPI();  // Carregar os clientes da API de forma assíncrona
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar os clientes: {ex.Message}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Função para adicionar um novo cliente
        private void btnAddCliente_Click(object sender, RoutedEventArgs e)
        {
            // Cria a janela de cadastro de cliente
            var janelaCadastro = new cadCliente
            {
                Owner = Window.GetWindow(this)  // Define a janela principal como a "owner"
            };

            // Cria o ViewModel para a janela de cadastro
            var viewModel = new ClienteCadastroViewModel(janelaCadastro.Close);
            janelaCadastro.DataContext = viewModel;  // Define o DataContext da janela
            janelaCadastro.ShowDialog();  // Exibe a janela de cadastro
        }

        // Função para editar um cliente ao dar duplo clique no DataGrid
      
        private void btnEditar_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnExcluir_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
