using System;
using System.Windows;

namespace WpfVendas.Views
{
    /// <summary>
    /// Lógica interna para cadFornecedor.xaml
    /// </summary>
    public partial class cadFornecedor : Window
    {
        public cadFornecedor()
        {
            InitializeComponent();
        }

        private void Button_ClickSalvar(object sender, RoutedEventArgs e)
        {

        }

        private void Button_ClickVoltar(object sender, RoutedEventArgs e)
        {

        }
    }
}
