using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Net.Http;
using System.Net.Http.Json;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;
using WPFVendas.Models;

namespace WpfVendas.ViewModels
{
    public class FornecedorViewModel : INotifyPropertyChanged
    {
        private readonly HttpClient _httpClient;
        private Fornecedor _fornecedor;

        public ObservableCollection<Fornecedor> Fornecedores { get; set; }
        public ICommand SalvarCommand { get; }
        public ICommand CancelarCommand { get; }

        public Fornecedor Fornecedor
        {
            get => _fornecedor;
            set
            {
                _fornecedor = value;
                OnPropertyChanged();
            }
        }

        public FornecedorViewModel(Fornecedor fornecedor = null)
        {
            _httpClient = new HttpClient();
            Fornecedores = new ObservableCollection<Fornecedor>();
            Fornecedor = fornecedor ?? new Fornecedor();

            SalvarCommand = new RelayCommand(Salvar, CanSave);
            CancelarCommand = new RelayCommand(Cancelar);

            // Carregar fornecedores da API ao inicializar
            CarregarFornecedoresDaAPI();
        }

        // M�todo para carregar fornecedores da API
        public async Task CarregarFornecedoresDaAPI()
        {
            try
            {
                var apiUrl = "http://localhost:5299/Api/GetFornecedores";
                var fornecedoresDaApi = await _httpClient.GetFromJsonAsync<Fornecedor[]>(apiUrl);

                if (fornecedoresDaApi != null)
                {
                    Fornecedores.Clear();
                    foreach (var fornecedor in fornecedoresDaApi)
                    {
                        Fornecedores.Add(fornecedor);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao buscar fornecedores: {ex.Message}");
            }
        }

        // M�todo para salvar o fornecedor
        private async void Salvar()
        {
            if (Fornecedor != null)
            {
                try
                {
                    var apiUrl = "http://localhost:5299/Api/SalvarFornecedor";

                    // Caso o fornecedor tenha um ID, ent�o deve ser uma atualiza��o, sen�o � um novo fornecedor
                    HttpResponseMessage response;
                    if (Fornecedor.Id > 0)
                    {
                        response = await _httpClient.PutAsJsonAsync(apiUrl, Fornecedor);
                    }
                    else
                    {
                        response = await _httpClient.PostAsJsonAsync(apiUrl, Fornecedor);
                    }

                    if (response.IsSuccessStatusCode)
                    {
                        // Se for uma opera��o bem-sucedida, atualize a lista local e feche a janela
                        await CarregarFornecedoresDaAPI();
                        // Aqui voc� pode adicionar l�gica para fechar a janela ou dar feedback ao usu�rio
                        Console.WriteLine("Fornecedor salvo com sucesso.");
                    }
                    else
                    {
                        Console.WriteLine("Erro ao salvar fornecedor.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao salvar fornecedor: {ex.Message}");
                }
            }
        }

        // M�todo para verificar se o fornecedor pode ser salvo
        private bool CanSave()
        {
            // Por exemplo, voc� pode garantir que o nome, cidade e telefone estejam preenchidos
            return !string.IsNullOrEmpty(Fornecedor.Nome) &&
                   !string.IsNullOrEmpty(Fornecedor.Cidade) &&
                   !string.IsNullOrEmpty(Fornecedor.Telefone);
        }

        // M�todo para cancelar e fechar a janela
        private void Cancelar()
        {
            // Aqui voc� pode colocar a l�gica de fechar a janela ou voltar � tela anterior.
            // Por exemplo:
            Console.WriteLine("Cadastro cancelado.");
        }

        // Evento para notificar mudan�as nas propriedades
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
