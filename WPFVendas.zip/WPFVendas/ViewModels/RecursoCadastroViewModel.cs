using System.ComponentModel;
using System.Net.Http;
using System.Net.Http.Json;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using WPFVendas.Models;

namespace WpfVendas.ViewModels
{
    internal class RecursoCadastroViewModel : INotifyPropertyChanged
    {
        private readonly HttpClient _httpClient;
        private Recurso _recurso;
        
        public Recurso Recurso
        {
            get => _recurso;
            set
            {
                _recurso = value;
                OnPropertyChanged();
            }
        }

        public ICommand SalvarCommand { get; }
        public ICommand CancelarCommand { get; }

        private readonly Action _fecharAction;

        public RecursoCadastroViewModel(Action fecharAction, Recurso recurso = null)
        {
            _fecharAction = fecharAction;
            _httpClient = _httpClient ?? new HttpClient();
            Recurso = recurso ?? new Recurso(); // Se o recurso for null, criamos um novo.
            SalvarCommand = new RelayCommand(SalvarRecurso);
            CancelarCommand = new RelayCommand(Cancelar);
        }

        private void SalvarRecurso(object obj)
        {
            if (Recurso != null)
            {
                if (Recurso.Id == 0)
                {
                    CriarRecurso(Recurso);
                }
                else
                {
                    AtualizarRecursoAsync(Recurso);
                }

                _fecharAction();
            }
        }

        private void CriarRecurso(Recurso recurso)
        {
            // Lógica para criação do recurso (incluir recurso na base de dados, etc.)
            try
            {
                var apiUrl = "http://localhost:5299/Api/CreateRecurso";
                var response = _httpClient.PostAsJsonAsync(apiUrl, recurso).Result;

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show($"Recurso {recurso.Nome} criado com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show($"Erro ao criar o recurso: {response.StatusCode}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao criar o recurso: {ex.Message}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task AtualizarRecursoAsync(Recurso recurso)
        {
            try
            {
                var apiUrl = $"http://localhost:5299/Api/UpdateRecurso/{recurso.Id}";
                var response = await _httpClient.PutAsJsonAsync(apiUrl, recurso);

                if (response.StatusCode == System.Net.HttpStatusCode.NoContent)
                {
                    MessageBox.Show($"Recurso {recurso.Nome} atualizado com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show($"Erro ao salvar o recurso: {response.StatusCode}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao atualizar o recurso: {ex.Message}");
            }
        }

        private void Cancelar(object obj)
        {
            _fecharAction(); // Fecha a janela sem salvar
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
