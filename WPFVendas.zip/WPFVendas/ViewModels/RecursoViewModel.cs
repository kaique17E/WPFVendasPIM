using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Net.Http;
using System.Net.Http.Json;
using System.Runtime.CompilerServices;
using WPFVendas.Models;

namespace WpfVendas.ViewModels
{
    public class RecursoViewModel : INotifyPropertyChanged
    {
        private readonly HttpClient _httpClient;

        public ObservableCollection<Recurso> Recursos { get; set; }
        public Recurso Recurso { get; set; }

        public RecursoViewModel()
        {
            _httpClient = new HttpClient();
            Recursos = new ObservableCollection<Recurso>();
            //CarregarRecursosDaAPI();
        }

        public async Task CarregarRecursosDaAPI()
        {
            try
            {
                var apiUrl = "http://localhost:5299/Api/GetRecursos"; // Substituído para a API de recursos
                var recursosDaApi = await _httpClient.GetFromJsonAsync<Recurso[]>(apiUrl);

                if (recursosDaApi != null)
                {
                    foreach (var recurso in recursosDaApi)
                    {
                        Recursos.Add(recurso);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao buscar recursos: {ex.Message}");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
