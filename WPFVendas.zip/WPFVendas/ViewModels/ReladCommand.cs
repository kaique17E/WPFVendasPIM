﻿using System;
using System.Windows.Input;

namespace WpfVendas.ViewModels
{
    public class RelayCommand : ICommand
    {
        private readonly Action<object> _execute;
        private readonly Func<object, bool> _canExecute;
        private Action salvar;
        private Func<bool> canSave;
        private Action cancelar;

        public RelayCommand(Action<object> execute, Func<object, bool> canExecute = null)
        {
            _execute = execute;
            _canExecute = canExecute;
        }

        public RelayCommand(Action salvar, Func<bool> canSave)
        {
            this.salvar = salvar;
            this.canSave = canSave;
        }

        public RelayCommand(Action cancelar)
        {
            this.cancelar = cancelar;
        }

        public bool CanExecute(object parameter)
        {
            return _canExecute == null || _canExecute(parameter);
        }

        public void Execute(object parameter)
        {
            _execute(parameter);
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }
    }
}
